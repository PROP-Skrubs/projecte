package CapaVista;

/**
 * Created by daniel on 14/11/15.
 */
public class PuntEntrada
{
    public static void main(String[] args)
    {
        new MenuLogin();
    }
}
