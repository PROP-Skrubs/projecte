package CapaDomini;

public interface TaulerDisplayerCallbacks
{
    public boolean casellaModificada(Casella c);
}
